INSERT INTO MEMBER (id, passwd, name) VALUES ('admin', '1234', '������');
INSERT INTO MEMBER (id, passwd, name) VALUES ('honggd', 'hong1234', 'ȫ�浿');