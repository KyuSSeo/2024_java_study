package ch07;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
public class HashMapDicEx {
	public static void main(String[] args) {
		// 영어 단어와 한글 단어의 쌍을 저장하는 HashMap 컬렉션 생성
		HashMap<String, String> dic = new HashMap<String, String>(); 
		// var dic = new HashMap<String, String>(); 나 HashMap<String, String> dic = new HashMap<>();로 해도 됨
		
		// 3 개의 (key, value) 쌍을 dic에 저장
		dic.put("baby", "아기"); // "baby"는 key, "아기"은 value
		dic.put("love", "사랑"); 
		dic.put("apple", "사과");
	
		// dic 해시맵에 들어 있는 모든 (key, value) 쌍 출력
		Set<String> keys = dic.keySet(); // 키를 모두 Set 컬렉션에 받아옴
		Iterator<String> it = keys.iterator(); // Set에 저장된 키 문자열을 접근할 수 있는 Iterator 리턴
		while(it.hasNext()) {
			String key = it.next(); // 키
			String value = dic.get(key); // 값
			System.out.print("(" + key + "," + value + ")");
		}
		System.out.println();
		
		// 사용자로부터 영어 단어를 입력받고 한글 단어 검색
		Scanner scanner = new Scanner(System.in);
		for(int i=0; i<3; i++) {
			System.out.print("찾고 싶은 단어는?");
			String eng = scanner.next();
			// 해시맵에서 '키' eng의 '값' kor 검색
			String kor = dic.get(eng); // eng가 해시맵에 없으면 null 리턴
			if(kor == null) System.out.println(eng +"는 없는 단어 입니다.");
			else System.out.println(kor); 
		}
		scanner.close();
	}
}